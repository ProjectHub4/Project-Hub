<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Dashboard | Student</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container" >
        <div class="navigation" >
            <ul>
                <li>
                    <a href="index1.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index1.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="meeting.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="review.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

               

                <li>
                    <a href="upload.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Files</span>
                    </a>
                </li>

                

                <li>
                    <a href="index.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main" style="background-color:#f5f5f5;">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b>Student</b></h1>
                

                <div class="user">
                
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox"  >
                <div class="card" >
                    <div>
                        <div class="numbers" >Announcement</div>
                        <div class="cardName">Submit your proposal by 25-jan-2022</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>

                <div class="card">
                    <div>
                        <div class="numbers">Announcement</div>
                        <div class="cardName">Meeting will be held on the 1st week of february</div>
                    </div>

                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>

                

               
            </div>

            <!-- ================ Order Details List ================= -->
            <div class="details" >
                <div class="recentOrders" style="background-color:#f5f5f5;">
                    <div class="cardHeader">
                        <h2><b>Projects</b></h2>
                        <a href="#" class="btn">View All</a>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <td>Project title</td>
                                <td><center>Supervisor</center></td>
                                <td>Remark</td>
                                <td>Status</td>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>Project hub</td>
                                <td><center>Ms. Soomaiya Hamid</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>PakStan</td>
                                <td><center>Sir. salahuddin shaikh</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>Vision on way</td>
                                <td><center>Ms. Tehreem Qamar</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>Track in way</td>
                                <td><center>Ms. Hafiza Anisa Ahmed</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>Smart Employer</td>
                                <td><center>Ms. Sumaira Ahmed</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>Route to salah</td>
                                <td><center>Ms. Sadia Javed</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>Memory Bank</td>
                                <td><center>Sir. Saifullah Adnan</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>

                            <tr>
                                <td>CuraPets</td>
                                <td><center>Sir. Saifullah Adnan</center></td>
                                <td>Satisfied</td>
                                <td><span class="status pending">In progress</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- ================= New Customers ================ -->
                <div class="recentCustomers" style="background-color:#f5f5f5;">
                    <div class="cardHeader" >
                        <h2>Timeline</h2>
                    </div>

                    <table>
                        <tr>
                            <td width="60px">
                            <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                            </td>
                            <td>
                                <h4>Submission <br> <span>Proposal is due</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                            <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                            </td>
                            <td>
                                <h4>Srs Report <br> <span>uploaded</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                            <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                            </td>
                            <td>
                                <h4>Meeting <br> <span>All groups are required to come in D-20 for FYP discussion</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                            <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                            </td>
                            <td>
                                <h4>Report Submission <br> <span>Ignite</span></h4>
                            </td>
                        </tr>

                        <tr>
                            <td width="60px">
                            <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                            </td>
                            <td>
                                <h4>Mid presentation<br> <span>FYP1</span></h4>
                            </td>
                        </tr>

                        

                        

                       
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>