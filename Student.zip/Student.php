

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Student Page </title>
        
        <link rel="stylesheet" href="design.css">
</head>

<body>
    <div class="container"  style="background-image: url(https://wallpaperaccess.com/full/1567677.jpg);  ">

    <div class="content">
      
    <h3>Hi, <span>Student</span></h3>
</br>
</br>
<h1>Welcome <span>to ProjectHub</span> </h1>
</br>
</br>
       
<a href="index1.php" class="btn">Continue</a>

    </div>
    </div>
</body>
</html>