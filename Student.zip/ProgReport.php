<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Dashboard | Progress Report</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container" >
        <div class="navigation" >
            <ul>
                <li>
                    <a href="index1.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index1.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="meeting.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="review.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

               
                <li>
                    <a href="upload.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Files</span>
                    </a>
                </li>

                

                <li>
                    <a href="Login_form.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <div class="main" style="background-color:#f5f5f5;">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b>Student-Progress Report</b></h1>
                

                <div class="user">
                
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox" >
                

                

                

               
            </div>

            <!-- ================ Order Details List ================= -->
            <div class="details" >
                <div class="recentOrders" style="background-color:#f5f5f5;">
                    <div class="cardHeader">
                        <h2><b>PROGRESS REPORT</b></h2>
                        <a href="#" class="btn">Refresh</a>
                    </div>

                    <table>
                        <thead>
                            <tr>
                                <td>Project id</td>
                                <td><center>Project Title</center></td>
                                <td>Overall Performance</td>
                                <td><center>Remark</center></td>
                                <td>Marks</td>
                                <td>Status</td>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><center>Project hub</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>2</td>
                                <td><center>PakStan</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>3</td>
                                <td><center>Vision on way</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>4</td>
                                <td><center>Track in way</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>5</td>
                                <td><center>Smart Employer</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>6</td>
                                <td><center>Route to salah</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>7</td>
                                <td><center>Memory Bank</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>

                            <tr>
                                <td>8</td>
                                <td><center>CuraPets</center></td>
                                <td>Good</td>
                                <td><center>Excellent work.</center></td>
                                <td>75/100</td>
                                <td><span class="status delivered">Pass</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

   <!-- ================= New Customers ================ -->
                
           

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>