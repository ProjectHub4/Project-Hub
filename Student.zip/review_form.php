<!DOCTYPE html>
<html>
<head>
	<title>Review Form</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
     <form action=""  method="post">
	 

     	<h2>Add Review</h2>

     	<label>Project title</label>
     	<input type="text" name="project_title" placeholder="Enter Project title"><br>

     	<label>Review</label>
     	<input type="text" name="review" placeholder="Enter review"><br>

       

     	

     	<input type="submit" class="txt" name="insert" value="Upload"/>
     </form>
     </body>
</html>

