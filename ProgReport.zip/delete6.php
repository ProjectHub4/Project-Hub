<?php
	$id=$_GET['id'];
	include('connection.php');
	mysqli_query($con,"delete from `faculty_form` where id='$id'");
	header('location:faculty.php');
?>