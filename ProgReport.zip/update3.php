<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$title=$_POST['title'];
	$grade=$_POST['grade'];
	$date=$_POST['date'];
	$academicyear=$_POST['academicyear'];
	$time=$_POST['time'];
    $degreeprogram=$_POST['degreeprogram'];
 
	mysqli_query($con,"update `activity` set title='$title', grade='$grade', date='$date', academicyear='$academicyear', time='$time', degreeprogram='$degreeprogram' where id='$id'");
	header('location:activity.php');
?>