<?php
	include('connection.php');
 
	$projecttitle=$_POST['projecttitle'];
	$date=$_POST['date'];
	
    $time=$_POST['time'];
	$Status=$_POST['Status'];
	mysqli_query($con,"insert into `meetingform` (projecttitle,date,time,Status) values ('$projecttitle','$date','$time','$Status')");
	header('location:meeting2.php');
 
?>