<?php
	include('connection.php');
 
	$name=$_POST['name'];
	$designation=$_POST['designation'];
	
    $password=$_POST['password'];
	$position=$_POST['position'];
	mysqli_query($con,"insert into `faculty` (name,designation,password,position) values ('$name','$designation','$password','$position')");
	header('location:faculty.php');
 
?>