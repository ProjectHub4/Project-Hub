<?php
	include('connection.php');
 
	$title=$_POST['title'];
	$date=$_POST['date'];
	$academicyear=$_POST['academicyear'];
	$time=$_POST['time'];
    $degreeprogram=$_POST['degreeprogram'];
	mysqli_query($con,"insert into `activity` (title,date,academicyear,time,degreeprogram) values ('$title','$date','$academicyear','$time','$degreeprogram')");
	header('location:activity.php');
 
?>