<?php
	$id=$_GET['id'];
	include('connection.php');
	mysqli_query($con,"delete from `announcement_form` where id='$id'");
	header('location:Admin.php');
?>