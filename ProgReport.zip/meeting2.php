<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>  Project Cordinator | Meeting</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container" style="background-color:#2a2185;" >
        <div class="navigation"  style="background-color:#2a2185;">
            <ul>
                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="activity.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Activity</span>
                    </a>
                </li>
                <li>
                    <a href="meeting2.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport2.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

                <li>
                    <a href="project2.php">
                        <span class="icon">
                            <ion-icon name="book-outline"></ion-icon>
                        </span>
                        <span class="title">Projects</span>
                    </a>
                </li>

                <li>
                    <a href="review2.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>
               

                
                <li>
                    <a href="Templates2.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Templates</span>
                    </a>
                </li>

 
               

                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 3px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
body
{
  font-family:sans-serif;
  background: #A9A6CE;
  min-height: 50vh;
}
.center,.content
{
  position:absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%);
}
.click-me
{
  display:block;
  width:100px;
  height:50px;
  background: #A9A6CE;
  
  text-align:center;
  font-size:18px;
  line-height:20px;
  cursor:pointer;
}
#click
{
  display:none;
}
.click-me:hover
{
  color: #2a2185;
}
.content
{
  visibility:hidden;  
  width: 300px;
  height: auto;
  background: #2a2185;
  padding: 30px 35px 40px;
  box-sizing: border-box;
  border-radius: 5px;
}
#temp
{
  position:absolute;
  right:10px;
  top:20px;
  font-size:25px;
  background: #dde1e7;
  padding: 3px;
  padding-left: 11px;
  padding-right: 11px;
  border-radius: 50%;
  cursor:pointer;
}
#click:checked~.content
{
  opacity:1;
  visibility:visible;
}
.text
{
  font-size: 30px;
  color: #fff;
  font-weight: 600;
  text-align: center;
  letter-spacing: 2px;
}
form
{
  margin-top: 40px;
}
label
{
  display: block;
  margin-top: 30px;
  font-size: 16px;
  font-weight: 500;
}
input
{
  display: block;
  height: 43px;
  width: 100%;
  background-color: #fff;
  border-radius: 3px;
  border: none;

  margin-top: 8px;

  font-size: 18px;
  font-weight: 300;
}
::placeholder
{
  color: #4b4e4d;
  padding-left: 10px;
}
button
{
width: 100%;
margin-top: 35px;
display:inline-block;
border-radius:9px;
background-color: #dde1e7;
border:none;
color: #2a2185;
text-align: center;
font-size: 20px;
padding: 3px;
width: 180px;
transition: all 0.5s;
cursor:pointer:
margin: 5px;
}
.main{
            background-image:url(https://img.freepik.com/premium-vector/white-background-with-halftone_67845-798.jpg?w=2000);
        }
        </style>
        <div class="main" >
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b>PROJECT CO-ORDINATOR | MEETING</b></h1>
                

                <div class="user">
                
                
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox" >
                
               
                
              
               
            </div>
            <!-- ================ Order Details List ================= -->
            <?php include 'connection.php'; ?>
            <div class="details" >
                <div class="recentOrders" style="background-color:#f5f5f5;">
                    <div class="cardHeader">
                        <h2><b>MEETING STATUS</b></h2>
                        <a href="meeting_form.php">
                <button class="button" style="vertical-align:middle" ><span>+Schedule Meeting</span> </button><br><br>
    </a>
    
                        </div>

<table>

    <thead>
        <table border="3px" cellppadding="3px" cellspacing="3px">
        <tr style="background-color: #A9A6CE;">
        <td><center><b>#</b></center></td>
           <td><center><b>PROJECT TITLE</b></center></td>
           <td><center><b>DATE</b></center></td>
            <td><center><b>TIME</b></center></td>
            <td><center><b>DISCUSSION</b></center></td>
            <td><center><b>TASK TO DO</b></center></td>
            <td><center><b>STATUS</b></center></td>
            <td colspan="2"><center><b></b></center></td>
            
            <tr style="background-color: #A9A6CE;">
                            <td><center><b></b></center></td>
                            <td><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan="2"><center><b>Actions</b></center></td><br>
                            
                           
                     
        </tr>
           
        
    </thead>

    <tbody>
  
      
    </tbody>
    <?php
    $count=1;
        $query="SELECT * FROM meetingform";
        $data=mysqli_query($con,$query);
        $result=mysqli_num_rows($data);
        if ($result) {
            while ($row=mysqli_fetch_array($data)) {
                ?>
                <tr>
                    <td><center><b><?php echo $count; ?></td></center></b></td>
                    <td><center><b><?php echo $row['projecttitle']; ?></center></b></td>
                    <td><center><b><?php echo $row['date']; ?></center></b></td>
                    <td><center><b><?php echo $row['time']; ?></center></b></td>
                    <td><center><b><?php echo $row['discussion']; ?></center></b></td>
                    <td><center><b><?php echo $row['tasktodo']; ?></center></b></td>
                    <td><center><b><span class="status inProgress"><?php echo $row['Status']; ?></span></center></b></td> 
                    <td><center><b><a href="edit4.php?id=<?php echo $row['id']; ?>"style="color: green"><ion-icon name="create-outline"  size="large"></a></center></b></td>
                    <td><center><b><a href="delete3.php?id=<?php echo $row['id']; ?>"style="color: red";><ion-icon name="close-circle-outline" size="large" ></a></center></b></td>
                   </tr>
                <?php $count++; } }
                ?>


</table>

</div>


                

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>
 
    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
</body>
</html>