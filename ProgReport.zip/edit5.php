<?php
	include('connection.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"select * from `progress_form` where id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Form</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<style>
    .button{
        display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
    }
    .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;

    }

    .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }
    .button:hover span{
            padding-right: 25px;
        }

    .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
    </style>
</head>
<body>
	
	<form method="POST" action="update5.php?id=<?php echo $id; ?>">
    <h2>Edit Progress Form</h2>
        <label><b>Project Title:</b></label><input type="text" value="<?php echo $row['projecttitle']; ?>" name="projecttitle">
        <label><b>Student Names</b></label><br>
        <label><b>1.</b></label><input type="text" value="<?php echo $row['student1']; ?>" name="student1">
        <label><b>2.</b></label><input type="text" value="<?php echo $row['student2']; ?>"name="student2">
        <label><b>3.</b></label><input type="text" value="<?php echo $row['student3']; ?>"name="student3">
        <label><b>4.</b></label><input type="text" value="<?php echo $row['student4']; ?>" name="student4">
		<label><b>Tasks:</b></label><br>
        <label>1.Code Evaluation</label><input type="text" value="<?php echo $row['CodeEvaluation']; ?>" name="CodeEvaluation">
        <label>2.Project Evaluation</label><input type="text" value="<?php echo $row['ProjectEvaluation']; ?>" name="ProjectEvaluation">
        <label>3.Performance</label><input type="text" value="<?php echo $row['Performance']; ?>" name="Performance">
        <label>4.Participation</label><input type="text" value="<?php echo $row['Participation']; ?>" name="Participation">
        <label>5.Mid Evaluation</label><input type="text" value="<?php echo $row['MidEvaluation']; ?>" name="MidEvaluation">
        <label>6.Final Evaluation</label><input type="text" value="<?php echo $row['FinalEvaluation']; ?>" name="FinalEvaluation">
       
        <label><b>Remarks</b></label><select value ="<?php echo $row['remarks']; ?>" name="remarks">
        <option value="Select">Select</option>
                <option value="Excellent">Excellent</option>
                <option value="Good">Good</option>
                <option value="Fair">Fair</option>
            </select>
            <br>
        <br>
            <label><b>Project Status</b></label><select value ="<?php echo $row['status']; ?>" name="status">
        <option value="Select">Select</option>
                <option value="None">None</option>
                <option value="Satisfactory">Satisfactory</option>
                <option value="Unsatisfactory">Unsatisfactory</option>
            </select>
            <br>
        <br>
        <button class="button" style="vertical-align:middle" name="save_btn" ><span>Submit</span> </button><br>
	
        <br>
        <br>
       
        <button class="button" onclick="location.href='ProgReport2.php';" value="Back" ><span>Cancel</span> </button><br><br>
	</form>
    <?php
if (isset($_POST['save_btn'])) {
    $projecttitle=$_POST['projecttitle'];
    $student1=$_POST['student1'];
    $student2=$_POST['student2'];
    $student3=$_POST['student3'];
    $student4=$_POST['student4'];
    $remarks=$_POST['remarks'];
    $CodeEvaluation=$_POST['CodeEvaluation'];
    $ProjectEvaluation=$_POST['ProjectEvaluation'];
    $Performance=$_POST['Performance'];
    $Participation=$_POST['Participation'];
    $MidEvaluation=$_POST['MidEvaluation'];
    $FinalEvaluation=$_POST['FinalEvaluation'];
    $status=$_POST['status'];

    $obtmarks=$CodeEvaluation+$ProjectEvaluation+$Performance+$Participation+$MidEvaluation+$FinalEvaluation;
    $totmarks=100;
    $grade=($obtmarks/$totmarks)*100;

$query="INSERT INTO progress_form (
    projecttitle,student1,student2,student3,student4, remarks,CodeEvaluation,ProjectEvaluation,Performance,Participation,MidEvaluation,FinalEvaluation,status,obtmarks) VALUES('$projecttitle','$student1','$student2','$student3','$student4', '$remarks','$CodeEvaluation','$ProjectEvaluation','$Performance','$Participation','$MidEvaluation','$FinalEvaluation','$status','$obtmarks')";
   $data=mysqli_query($con,$query);
    if ($data) {
        ?>
       
        <?php
   header("location:ProgReport2.php");

    }
    else
    {
        ?>
        
        <?php
       

    }
    
}

?>

</body>
</html>