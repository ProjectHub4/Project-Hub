<?php
	include('connection.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"select * from `meetingform` where id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Form</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<style>
    .button{
        display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
    }
    .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;

    }

    .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0;
            right: -20px;
            transition: 0.5s;
        }
    .button:hover span{
            padding-right: 25px;
        }

    .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
    </style>
</head>
<body>
	
	<form method="POST" action="update6.php?id=<?php echo $id; ?>">
    <h2>Meeting Form</h2>
        <label><b>Project Title</b></label>
        <select name= "projecttitle">
             <option value="<?php echo $row['projecttitle']; ?>">Select</option>
                <option value="Project Hub">Project Hub</option>
                <option value="Cura Pets">Cura Pets</option>
                <option value="Glimpse">Glimpse</option>
                <option value="PakStan">PakStan</option>
            </select>
            <br><br>
       
        <label><b>Date:</b></label><input type="date" value="<?php echo $row['date']; ?>" name="date">
        <label><b>Time:</b></label><input type="time" value="<?php echo $row['time']; ?>" name="time">
        <label><b>Status:</b></label>
        <select name= "Status">
             <option value="<?php echo $row['Status']; ?>">Select</option>
             <option value="None">None</option>
                
                <option value="Attended">Attended</option>
              
                <option value="NotAttended">NotAttended</option>
    </select><br><br>
        <button class="button" style="vertical-align:middle" name="submit" ><span>Submit</span> </button><br>
	
        <br>
        <br>
       
        <button class="button" onclick="location.href='meeting3.php';" value="Back" ><span>Cancel</span> </button><br><br>
	</form>
</body>
</html>