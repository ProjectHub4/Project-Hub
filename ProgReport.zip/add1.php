<?php
	include('connection.php');
 
	$fullname=$_POST['fullname'];
	$enrollment=$_POST['enrollment'];
	$batch=$_POST['batch'];
	$year=$_POST['year'];
 
	mysqli_query($con,"insert into `students` (fullname,enrollment,batch,year) values ('$fullname','$enrollment','$batch','$year')");
	header('location:Admin-students.php');
 
?>