<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Activity | Supervisor</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<body>


</body>
    <!-- =============== Navigation ================ -->
    <div class="container" style="background-color:#2a2185;" >
        <div class="navigation"  style="background-color:#2a2185;">
            <ul>
                <li>
                    <a href="index3.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index3.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>


                <li>
                    <a href="activity3.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Activity</span>
                    </a>
                </li>

                <li>
                    <a href="meeting3.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport3.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

                <li>
                    <a href="project3.php">
                        <span class="icon">
                            <ion-icon name="book-outline"></ion-icon>
                        </span>
                        <span class="title">Projects</span>
                    </a>
                </li>

                <li>
                    <a href="review3.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>
               

                
                <li>
                    <a href="Templates3.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Templates</span>
                    </a>
                </li>

 
               

                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 3px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

         .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        } 
        input[type=text] {
        width: 100%;
        padding: 12px 120px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 3px solid #2a2185;
        border-radius: 11px;
       
        }
        input[type=button],
        input[type=submit] {
        background-color: #2a2185;
        border: none;
        color: #fff;
        padding: 15px 30px;
        text-decoration: none;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 12px;
        }
        .main{
            background-image:url(https://img.freepik.com/premium-vector/white-background-with-halftone_67845-798.jpg?w=2000);
        }

      

        </style>
      
        <div class="main" >
             
                          
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b><center>SUPERVISOR | ACTIVITY</center></b></h1>
                <div class="user">
                        
                <h1></h1>
                          
                          
                          </div>
            </div>
            

           <!-- ======================= Cards ================== -->
           <?php include 'connection.php'; ?>
            <div class="cardBox" style="width:150rem;">
                <div class="">
                
                    <div>
                   
                    
              </div>

                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>
            
                
                
                
               
                <div class="Button">
                    <div>
                   
               
 
   
    
    
                    </div>
                    
                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>

               
            </div>
            

            <!-- ================ Order Details List ================= -->
            <?php include 'connection.php';?>
            <div class="details" >
            <div class="recentOrders" style="background-color:#f5f5f5;">
            <div class="cardHeader">
            <h2><b>Activity Log</b></h2>
            <?php
error_reporting(0);
if(isset($_POST['search']))
{
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `activity` WHERE CONCAT( `degreeprogram`,'academicyear') LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `activity`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "project_hub");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>
                       <form action="activity3.php" method="post">
            <input type="text" name="valueToSearch" placeholder="Search Here..."><br><br>
        <input type="submit" style="vertical-align:middle" name="search" value="Search"><br><br>
</form>




                    </div>
            
                    <table>
                        
                    <thead>
                    <table border="3px" cellppadding="3px" cellspacing="3px" >
                            <tr style="background-color: #A9A6CE;">
                               
                                <td><center><b>TITLE</b></center></td>
                                <td><center><b>GRADE</b></center></td>
                                <td><center><b>DATE</b></center></td>
                               
                                
                                <td colspan=""><center><b>ACADEMIC YEAR</b></center></td><br>
                                
                               
                                <td><center><b>TIME</b></center></td>
                                <td><center><b>DEGREE PROGRAM</b></center></td>
                            
                               
                           
                            </tr>
                            
                            <tr style="background-color: #A9A6CE;">
                            <td><center><b></b></center></td>
                            <td><center><b></b></center></td>
                            
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                            <td colspan=""><center><b></b></center></td><br>
                         
                            
							
                           
                     
        </tr>
                            
                     </thead>

    
       
    <tbody>
</tbody>
    <?php
                       
                       include('connection.php');
                       $query=mysqli_query($con,"select * from activity");
                       while($row=mysqli_fetch_array($query)){
                           ?>
                           <tr>
                               <?php while($row = mysqli_fetch_array($search_result)):?>
                               <td><center><b><?php echo $row['title']; ?></td></center></b>
                               <td><center><b><?php echo $row['grade']; ?></td></center></b>
                               <td><center><b><?php echo $row['date']; ?></td></center></b>
                             
                               
                               <td><center><b><?php echo $row['academicyear']; ?></td></center></b>
                               <td><center><b><?php echo $row['time']; ?></td></center></b>
                               <td><center><b><?php echo $row['degreeprogram']; ?></td></center></b>
                               
                            
						</tr>
						<?php endwhile;?>
                <?php
            }
        
    ?>
                </div>
                       
                               
                
    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>
