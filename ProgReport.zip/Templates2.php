<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Templates | Project Coordinator</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
    
   
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container" style="background-color:#2a2185;" >
        <div class="navigation"  style="background-color:#2a2185;">
            <ul>
                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="activity.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Activity</span>
                    </a>
                </li>
                <li>
                    <a href="meeting2.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport2.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

                <li>
                    <a href="project2.php">
                        <span class="icon">
                            <ion-icon name="book-outline"></ion-icon>
                        </span>
                        <span class="title">Projects</span>
                    </a>
                </li>

                <li>
                    <a href="review2.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>
               

                
                <li>
                    <a href="Templates2.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Templates</span>
                    </a>
                </li>

 
               

                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>
         <!-- ========================= Main ==================== -->
         <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        .main{
            background-image:url(https://img.freepik.com/premium-vector/white-background-with-halftone_67845-798.jpg?w=2000);
        }
        input[type=text] {
        width: 50%;
        padding: 12px 120px;
        margin: 8px 0;
        box-sizing: border-box;
        border: 4px solid #2a2185;
        border-radius: 16px;
       
}
      input[type=button],
      input[type=submit]
      {
        background-color: #2a2185;
        border: none;
        color: #fff;
        padding: 15px 30px;
        text-decoration: none;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 12px;
        font-size:15px;
      }

        </style>
         <div class="main" >
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b>TEMPLATE FILE</b> </h1>
                
                <div class="user">
                
            </div>
            </div>
            
            <!-- ======================= Cards ================== -->
            <div class="cardBox" >
                
               
                
              
               
                </div>
            <!-- ================= New Customers ================ -->
            <?php include 'connection.php'; ?>
            

            <div class="recentCustomers" >
                    <div class="cardHeader" style="background-color:#f5f5f5;" >
                    <?php
$con=new PDO('mysql:host=localhost; dbname=project_hub', 'root', '') or die(mysql_error());
if(isset($_POST['submit'])!=""){
  $name=$_FILES['file']['name'];
  $size=$_FILES['file']['size'];
  $type=$_FILES['file']['type'];
  $temp=$_FILES['file']['tmp_name'];
  // $caption1=$_POST['caption'];
  // $link=$_POST['link'];
  $fname = date("YmdHis").'_'.$name;
  $chk = $con->query("SELECT * FROM  upload where name = '$name' ")->rowCount();
  if($chk){
    $i = 1;
    $c = 0;
	while($c == 0){
    	$i++;
    	$reversedParts = explode('.', strrev($name), 2);
    	$tname = (strrev($reversedParts[1]))."_".($i).'.'.(strrev($reversedParts[0]));
    // var_dump($tname);exit;
    	$chk2 = $con->query("SELECT * FROM  upload where name = '$tname' ")->rowCount();
    	if($chk2 == 0){
    		$c = 1;
    		$name = $tname;
    	}
    }
}
 $move =  move_uploaded_file($temp,"upload/".$fname);
 if($move){
 	$query=$con->query("insert into upload(name,fname)values('$name','$fname')");
	if($query){
	header("location:Templates2.php");
	}
	else{
	die(mysql_error());
	}
 }
}
?>



<body>

	    <div class="row-fluid">
	        <div class="span12">
	            <div class="container">
		<br />
		<h1 ><p>Upload  And  Download Files</p></h1>	
		<br />
		<br />
			<form height="20px" enctype="multipart/form-data" action="" name="form" method="post">
				<b>Select File</b>
					<input  type="file" name="file" id="file" />
					<input type="submit" name="submit" id="submit" value="Submit" />
			</form>
		<br />
		<br />
		<table cellpadding="5" cellspacing="5" border="5" color=" #A9A6CE" class="table table-striped table-bordered" id="example">
			<thead  style="background-color: #A9A6CE; ">
				<tr  style="background-color: #A9A6CE; ">
					<td width="100%" align="center"><b>FILES</b></td>
					<td width="50%"align="center"><b>ACTIONS</b></td>	
				</tr>
			</thead>
			<?php
			$query=$con->query("select * from upload order by id desc");
			while($row=$query->fetch()){
				$name=$row['name'];
			?>
			<tr>
			
				<td>
					&nbsp;<?php echo $name ;?>
				</td>
				<td>
					<b><button style="display:inline-block;
            border-radius:9px;
            background-color: #A9A6CE;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;" class="alert-success"><a style="text-decoration:none; color:white;" href="download.php?filename=<?php echo $name;?>&f=<?php echo $row['fname'] ?>">Download</a></b></button>
				</td>
			</tr>
			<?php }?>
		</table>
	</div>
	</div>
	</div>
    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>
    <script src="js/jquery.js" type="text/javascript"></script>
	<script src="js/bootstrap.js" type="text/javascript"></script>
	
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/jquery.dataTables.js"></script>
	<script type="text/javascript" charset="utf-8" language="javascript" src="js/DT_bootstrap.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>