<?php
	include('connection.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"select * from `faculty` where id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Form</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<style>
    .button{
        display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
    }
    .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;

    }

    .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0;
            right: -20px;
            transition: 0.5s;
        }
    .button:hover span{
            padding-right: 25px;
        }

    .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
    </style>
</head>
<body>
	
	<form method="POST" action="update2.php?id=<?php echo $id; ?>">
    <h2>Add Faculty Member</h2>
        <label><b>Name:</b></label><input type="text" value="<?php echo $row['username']; ?>" name="username">
        <label><b>Designation:</b></label><input type="text" value="<?php echo $row['designation']; ?>" name="designation">
        <label><b>Password:</b></label><input type="text" maxlength="4" value="<?php echo $row['password']; ?>" name="password">
        <label><b>Position:</b></label><input type="text" value="<?php echo $row['usertype']; ?>" name="usertype">
        <button class="button" style="vertical-align:middle" name="submit" ><span>Submit</span> </button><br>
	
        <br>
        <br>
       
        <button class="button" onclick="location.href='faculty.php';" value="Back" ><span>Cancel</span> </button><br><br>
	</form>
</body>
</html>