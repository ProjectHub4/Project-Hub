<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$username=$_POST['username'];
	$designation=$_POST['designation'];
	
    $password=$_POST['password'];
	$usertype=$_POST['usertype'];
 
	mysqli_query($con,"update `faculty_form` set username='$username', designation='$designation', password='$password', usertype='$usertype' where id='$id'");
	
	header('location:faculty.php');
?>

<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$username=$_POST['username'];
    $password=$_POST['password'];
	$usertype=$_POST['usertype'];
 
	mysqli_query($con,"update `login` set username='$username', password='$password', usertype='$usertype' where id='$id'");
	
	header('location:faculty.php');
?>
