<?php
include('connection.php');
$id=$_GET['id'];
$query = "DELETE FROM project_form WHERE id=$id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: Admin.php"); 
?>

