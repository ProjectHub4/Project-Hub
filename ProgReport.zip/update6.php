<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$projecttitle=$_POST['projecttitle'];
	$date=$_POST['date'];
	
    $time=$_POST['time'];
	$Status=$_POST['Status'];
 
	mysqli_query($con,"update `meetingform` set projecttitle='$projecttitle', date='$date', time='$time', Status='$Status' where id='$id'");
	
	header('location:meeting3.php');
?>


