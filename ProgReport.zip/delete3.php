<?php
	$id=$_GET['id'];
	include('connection.php');
	mysqli_query($con,"delete from `meetingform` where id='$id'");
	header('location:meeting2.php');
?>