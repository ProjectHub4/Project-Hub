<?php  
 if(isset($_POST["id"]))  
 {  
$output = '';    
$con = new mysqli('localhost', 'root', "", 'projecthub');
$sql = "SELECT * FROM meetingform WHERE id = '".$_POST["employee_id"]."'";
$result = $con->query($sql) or trigger_error($con->error.”[$sql]”);
 }
 ?>