<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$projecttitle=$_POST['projecttitle'];
    $student1=$_POST['student1'];
    $student2=$_POST['student2'];
    $student3=$_POST['student3'];
    $student4=$_POST['student4'];
    $remarks=$_POST['remarks'];
    $CodeEvaluation=$_POST['CodeEvaluation'];
    $ProjectEvaluation=$_POST['ProjectEvaluation'];
    $Performance=$_POST['Performance'];
    $Participation=$_POST['Participation'];
    $MidEvaluation=$_POST['MidEvaluation'];
    $FinalEvaluation=$_POST['FinalEvaluation'];
    $status=$_POST['status'];
	
	mysqli_query($con,"update `progress_form` set projecttitle='$projecttitle', student1='$student1', student2='$student2', student3='$student3',student4='$student4', remarks='$remarks', CodeEvaluation='$CodeEvaluation', ProjectEvaluation='$ProjectEvaluation', Performance='$Performance', Participation='$Participation', MidEvaluation='$MidEvaluation', FinalEvaluation='$FinalEvaluation', status='$status', obtmarks='$obtmarks'where id='$id'");
	
	header('location:ProgReport2.php');
?>


