<?php include 'connection.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Progress Form</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
    <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
        </style>
</head>
<body>
<form action="" method="POST">

	 <h2>Add Project Performance</h2>
     
<div>

        <label><b>Project Title</b></label>
     	<select name= "projecttitle">
             <option value="select">Select</option>
                <option value="Project Hub">Project Hub</option>
                <option value="Cura Pets">Cura Pets</option>
                <option value="Glimpse">Glimpse</option>
                <option value="PakStan">PakStan</option>
            </select>
            <br><br>

            <label><b>Tasks</b></label>
     	   <input type="text" name="task" required placeholder="Enter Task Here."><br>

            <label><b>Remarks</b></label>
     	    <input type="text" name="remarks"  placeholder="Enter Remarks here."><br>

             
                 
<br>

        <form>
        <label><b>Project Status</b></label>
            <select name= "status">
                <option value="select">Select</option>
                <option value="None">None</option>
                <option value="Satisfactory">Satisfactory</option>
                <option value="Unsatisfactory">Unsatisfactory</option>
            </select>
            <br>
            <br>
        
        
        
        
            <button class="button" style="vertical-align:middle" name="save_btn" ><span>Submit</span> </button>
        <br>
        <br>
        <br>
        <button class="button" onclick="location.href='ProgReport3.php';" value="Back" ><span>Back</span> </button><br><br>
</form>
</div>

     

<?php
if (isset($_POST['save_btn'])) {
    $projecttitle=$_POST['projecttitle'];
    $task=$_POST['task'];
    $remarks=$_POST['remarks'];
    
    $status=$_POST['status'];

$query="INSERT INTO progress_form (
    projecttitle,task, remarks,status) VALUES('$projecttitle','$task','$remarks','$status')";
   $data=mysqli_query($con,$query);
    if ($data) {
        ?>
        
        <?php
   header("location:ProgReport3.php");

    }
    else
    {
        ?>
        
        <?php
    }
    
}

?>

</body>
</html>