<?php include 'connection.php';?>
<!DOCTYPE html>
<html>
<head>

    <title></title>
    <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 210px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0;
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 15px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
        </style>
    <link rel="stylesheet" type="text/css" href="style2.css">
    </head>
    <body>
        <form method="POST">
            <h2>Add Progress Report</h2>
            <div>
            
                <label><b>Code Evaluation</b></label>
                <input type="text" name="txteng" required maxlength="1" maxsize="1,2,3,4,5" placeholder="Enter Marks out of 10"><br>
                <label><b>Project Evaluation</b></label>
                <input type="text" name="txtmath" required maxlength="1" placeholder="Enter Marks out of 5"><br>
                <label><b>Performance</b></label>
                <input type="text" name="txtphp" required maxlength="1" placeholder="Enter Marks out of 5"><br>
                <label><b>Participation</b></label>
                <input type="text" name="txtjava" required maxlength="1" placeholder="Enter Marks out of 10"><br>
                <label><b>Mid Evaluation</b></label>
                <input type="text" name="txthtml" required maxlength="2" placeholder="Enter Marks out of 20"><br>
                <label><b>Final Evaluation</b></label>
                <input type="text" name="txtcc" required maxlength="2" placeholder="Enter Marks out of 50"><br>
                <button class="button" style="vertical-align:middle" name="submit" ><span>Calculate</span></button><br><br>

</form>




<table border="3px" width="60%">
    <tr style="background-color: #A9A6CE;">
    
                
        <tr style="background-color: #A9A6CE;">
            <td><b>
                ACTIVITIES
</b></td>
                <td><b>
                    MARKS
</b></td>
</tr>
<tr>
    <td>Code Evaluation</td>
    <td><?php echo $eng; ?></td>
<tr>
    <td>Project Evaluation</td>
    <td><?php echo $math; ?></td>
</tr>
<tr>
    <td>Performance</td>
    <td><?php echo $php; ?></td>
</tr>
<tr>
    <td>Participation</td>
    <td><?php echo $java; ?></td>
</tr>
<tr>
    <td>Mid Evaluation</td>
    <td><?php echo $html; ?></td>
</tr>
<tr>
    <td>Final Evaluation</td>
    <td><?php echo $cc; ?></td>
</tr>
<tr>
    <td><b>OBTAINED MARKS</b></td>
    <td><?php echo $obtmarks; ?></td>
</tr>

    <tr>
        <td><b>GRADE</b></td>
        <td><?php echo $performance; 
        if($performance>=90)
        {
            echo "passed";
        }
        else if($performance>=80)
        {
            echo "passed";
        }
        else if($performance>=75)
        {
            echo "passed";
        }
        else if($performance>=70)
        {
            echo "passed";
        }
        else if($performance<=60)
        {
            echo "fail";
        }
        ?>
    </td>
        </tr>
        </tr>
    
        
</table>
</div>
<?php
error_reporting(0);
if(isset($_POST['submit']))
{
    $eng=$_POST['txteng'];
    $math=$_POST['txtmath'];
    $php=$_POST['txtphp'];
    $java=$_POST['txtjava'];
    $html=$_POST['txthtml'];
    $cc=$_POST['txtcc'];

    $obtmarks=$eng+$math+$php+$java+$html+$cc;
    $totmarks=100;
    $performance=($obtmarks/$totmarks)*100;

    $query="INSERT INTO progress_form (
       performance) VALUES('$performance')";
       $data=mysqli_query($con,$query);
        if ($data) {
            ?>
           
            <?php
       
    
        }
        else
        {
            ?>
            
            <?php
        }
        
    }
    
    ?>

</body>
    </html>