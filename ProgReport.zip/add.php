<?php
	include('connection.php');
    $project_id = $_POST['project_id'];
    $password = $_POST['password'];
	$projecttitle = $_POST['projecttitle'];
    $student1 = $_POST['student1'];
    $student2 = $_POST['student2'];
    $student3 = $_POST['student3'];
    $student4 = $_POST['student4'];
    $batch = $_POST['batch'];
    $year = $_POST['year'];
    $supervisor = $_POST['supervisor'];
 
	mysqli_query($con,"insert into `project_form` (project_id,password,projecttitle,student1,student2,student3,student4,batch,year,supervisor) values ('$project_id','$password','$projecttitle','$student1', '$student2', '$student3', '$student4', '$batch','$year','$supervisor')");
	header('location:Admin.php');
 
?>