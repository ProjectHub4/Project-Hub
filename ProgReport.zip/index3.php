
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Dashboard | Supervisor</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>

<body>


</body>
    <!-- =============== Navigation ================ -->
    <div class="container" style="background-color:#2a2185;" >
        <div class="navigation"  style="background-color:#2a2185;">
            <ul>
                <br>
                <li>
                    <a href="index3.php">
                        <span class="icon">
                           
                        </span>
                        
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>
<br>
<br>
                <li>
                    <a href="index3.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="activity3.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Activity</span>
                    </a>
                </li>


                <li>
                    <a href="meeting3.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport3.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

                <li>
                    <a href="project3.php">
                        <span class="icon">
                            <ion-icon name="book-outline"></ion-icon>
                        </span>
                        <span class="title">Projects</span>
                    </a>
                </li>

                <li>
                    <a href="review3.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>
               

                
                <li>
                    <a href="Templates3.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Templates</span>
                    </a>
                </li>

 
               

                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 3px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

         .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        } 
        .main{
            background-image:url(https://img.freepik.com/premium-vector/white-background-with-halftone_67845-798.jpg?w=2000);
        }

      

        </style>
      
        <div class="main">
             
                          
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <h1><b><center> SUPERVISOR | DASHBOARD</center></b></h1>
                
                
                <div class="user">
                        
                <h1></h1>
                          
                          
                          </div>
                      
            </div>
            <h2 style="padding-left:39px;  color: #2a2185;"> Announcements </h2>

           <!-- ======================= Cards ================== -->
           <?php include 'connection.php'; ?>
           
            <div class="cardBox" style="width:150rem;">
           
                <div class="card">
             
                    <div>
                    <?php
                    $query="SELECT * FROM announcement_form";
                    $data=mysqli_query($con,$query);
                    $result=mysqli_num_rows($data);
                    if ($result) {
                    while ($row=mysqli_fetch_array($data)) {
                    ?>
                    
                 
                    <div class="cardName"> <?php echo $row['descrip']; ?></div> 
                        <div class="numbers"><b><?php echo $row['date']; ?></b></div><br>
                           
                            <?php
                            
                            
                }
                
            }
        ?>
                    
              </div>

                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>
            
                
                
                
                <br><br><br><br><br><br>
                <div class="Button">
                    <div>
                   
                <a href="announce_form1.php">
                <button class="button" style="vertical-align:middle"><span>+Add Announcement</span> </button><br><br>
    </a>
    
 
   
    
    
                    </div>
                    
                    <div class="iconBx">
                        <ion-icon name=""></ion-icon>
                    </div>
                </div>

               
            </div>
            <br><br><br>

            <!-- ================ Order Details List ================= -->
            <?php include 'connection.php';?>
            <div class="details">
            <div class="recentOrders" style="background-color:#f5f5f5;">
            <div class="cardHeader" >
            <h2><b>Recent Projects</b></h2>
            
            </div>

                    <table >
                        
    <thead>
    <table border="3px" cellppadding="3px" cellspacing="3px" >
                            <tr style="background-color: #A9A6CE; ">
                                <td ><center><b>#</b></center></td>
                                <td ><center><b>PASSWORD</b></center></td>
                                <td ><center><b>PROJECT TITLE</b></center></td>
                                <td colspan="4"><center><b>STUDENT NAMES</b></center></td><br>
                                <td ><center ><b>DEGREE PROGRAM</b></center></td>
                                <td ><center><b>ACADEMIC YEAR</b></center></td>
                                <td ><center><b>SUPERVISOR</b></center></td>
                               
                           
                            </tr>
                            
                           
                            <tr style="background-color: #A9A6CE;">
                            <td><center><b></b></center></td>
                            <td><center><b></b></center></td>
                            <td colspan=""><center><b>1.</b></center></td><br>
                            <td colspan=""><center><b>2.</b></center></td><br>
                            <td colspan=""><center><b>3.</b></center></td><br>
                            <td colspan=""><center><b>4.</b></center></td><br>
                            <td colspan=""><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td>
                           
                     
        </tr>
        
    </thead>

    
       
    <tbody>
    </tbody>
    <?php
                       
					include('connection.php');
					$query=mysqli_query($con,"select * from project_form");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
                           
                            <td><center><b><?php echo $row['project_id']; ?></td></center></b>
                            <td><center><b><?php echo $row['password']; ?></td></center></b>
                          
							<td ><center><a href="project2.php" style="text-decoration:none; color:black;" ><b><?php echo $row['projecttitle']; ?></td></center></b>
                    </a>
							<td ><center><b><?php echo $row['student1']; ?></td></center></b>
                            <td ><center><b><?php echo $row['student2']; ?></td></center></b>
                            <td ><center><b><?php echo $row['student3']; ?></td></center></b>
                            <td ><center><b><?php echo $row['student4']; ?></td></center></b>
                            <td ><center><b><?php echo $row['batch']; ?></td></center></b>
                            <td ><center><b><?php echo $row['year']; ?></td></center></b>
                            <td ><center><b><?php echo $row['supervisor']; ?></td></center></b>
                    
							
						</tr>
						<?php  } ?>
</table>
                </div>

              
                
    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>
