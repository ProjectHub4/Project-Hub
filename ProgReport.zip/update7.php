<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$projecttitle=$_POST['projecttitle'];
	$task=$_POST['task'];
	
    $remarks=$_POST['remarks'];
	$status=$_POST['status'];
 
	mysqli_query($con,"update `progress_form` set projecttitle='$projecttitle', task='$task', remarks='$remarks', status='$status' where id='$id'");
	
	header('location:ProgReport3.php');
?>


