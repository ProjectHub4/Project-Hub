<?php 

$server = "localhost";
$dbuser = "root";
$dbpass = "";
$database = "project_hub";

$conn = mysqli_connect($server, $dbuser, $dbpass, $database);

