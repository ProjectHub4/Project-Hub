<?php include 'connection.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Project Form</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
    
    <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
       

        
        </style>
</head>
<body>
<form class="form-inline" action="" method="POST">

	 <h2>Enroll Project</h2>
     
<div>
       <label><b>Project Id</b></label>
     	<input type="text" maxlength="11" name="project_id" required placeholder="Enter Project Id"><br>
         <label><b>Password</b></label>
     	<input type="text" maxlength="11" name="password" required placeholder="Enter Password"><br>

     	<label><b>Project Title</b></label>
     	<input type="text" name="projecttitle" required placeholder="Enter Project Title"><br>

       <label><b>1.Student</b></label>
     	<input type="text" name="student1" required placeholder="Enter Student"><br>
         <label><b>2.Student</b></label>
     	<input type="text" name="student2" required placeholder="Enter Student"><br>
         <label><b>3.Student</b></label>
     	<input type="text" name="student3" placeholder="Enter Student"><br>
         <label><b>4.Student</b></label>
     	<input type="text" name="student4"  placeholder="Enter Student"><br>
       
     	<label><b>Supervisor</b></label>
     	<select name= "supervisor" required placeholder="Select Supervisor">
                <option value="Select">Select</option>
                <option value="Ms.Soomaiya Hamid">Ms.Soomaiya Hamid</option>
                <option value="Ms.Anisa Ahmed">Ms.Anisa Ahmed</option>
                <option value="Ms.Sumaira Ahmed">Ms.Sumaira Ahmed</option>
                <option value="Dr.Saifullah Adnan">Dr.Saifullah Adnan</option>
                <option value="Ms.Kanwal Zahoor">Ms.Kanwal Zahoor</option>
                <option value="Ms.Ummay Faseeha">Ms.Ummay Faseeha</option>
                
            </select>
            <br><br>
            
 
            <label><b>Batch</b></label>
     	<select name= "batch" maxlength="2" required>
                <option value="Select">Select</option>
                <option value="CS">CS</option>
                <option value="SE">SE</option>
    </select>
    <br><br>
     
    <label><b>Year</b></label>
    <input type="text" name="year" maxlength="4" minlength="4" placeholder="Enter Year"><br>
    

           
       
           
          
    
        
        </form>
        
        
        <button class="button" style="vertical-align:middle" name="save_btn" ><span>Submit</span> </button><br>
    
        <br>
        <br>
       
        <button class="button" onclick="location.href='Admin.php';" value="Back" ><span>Cancel</span> </button><br><br>
        
        
</form>
</div>

     </form>

<?php
    if (isset($_POST['save_btn'])) {
    $project_id = $_POST['project_id'];
    $password = $_POST['password'];
    $projecttitle = $_POST['projecttitle'];
    $student1 = $_POST['student1'];
    $student2 = $_POST['student2'];
    $student3 = $_POST['student3'];
    $student4 = $_POST['student4'];
    $batch = $_POST['batch'];
    $year = $_POST['year'];
    $supervisor = $_POST['supervisor'];
   
   
    $query="INSERT INTO project_form (project_id,password,projecttitle, student1,student2,student3,student4,batch,year,supervisor) VALUES('$project_id','$password','$projecttitle','$student1', '$student2', '$student3', '$student4', '$batch','$year','$supervisor')";
    $data=mysqli_query($con,$query);
    if ($data) {
        ?>
        
        <?php
         header("location:Admin.php");

    }
    else
    {
        ?>
        
        <?php
    }
    
}



?>

</body>
</html>