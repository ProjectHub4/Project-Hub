<?php
	$id=$_GET['id'];
	include('connection.php');
	mysqli_query($con,"delete from `students` where id='$id'");
	header('location:Admin-students.php');
?>