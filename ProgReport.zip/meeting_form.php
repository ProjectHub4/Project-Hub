<?php include 'connection.php'; ?>

<!DOCTYPE html>
<html>
<head>
	<title>Meeting Form</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
    <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
        </style>
</head>
<body>
<form action="" method="POST">

	 <h2>MEETING FORM</h2>
<div>

     	<label><b>Project Title</b></label>
     	<select name= "projecttitle">
             <option value="select">Select</option>
                <option value="Project Hub">Project Hub</option>
                <option value="Cura Pets">Cura Pets</option>
                <option value="Glimpse">Glimpse</option>
                <option value="PakStan">PakStan</option>
            </select>
            <br><br>

     	<label><b>Date</b></label>
     	<input type="date" name="date" required><br>

         <label><b>Time</b></label>
     	<input type="time" name="time" required><br>

        
       
  
        <label><b>Status</b></label>
     	<select name= "Status">
             <option value="select">Select</option>
             <option value="None">None</option>
                
                <option value="Attended">Attended</option>
              
                <option value="NotAttended">NotAttended</option>
    </select>
    <br>
    <br>
    <label><b>Discussion</b></label>
     	<input type="text" name="discussion" required><br> 
        <br>  
        <label><b>Task To Do</b></label>
     	<input type="text" name="tasktodo" required><br> 
        <br>
        </form>
        <button class="button" style="vertical-align:middle" name="save_btn" ><span>Submit</span> </button>
        <br>
        <br>
        <br>
       
        </form>
</div>

     </form>

<?php
if (isset($_POST['save_btn'])) {
    $projecttitle=$_POST['projecttitle'];
    $date=$_POST['date'];
    $time=$_POST['time'];
    $discussion=$_POST['discussion'];
    $tasktodo=$_POST['tasktodo'];
    $Status=$_POST['Status'];
  

$query="INSERT INTO meetingform (
    projecttitle,date,time,Status) VALUES('$projecttitle','$date','$time','$discussion','$tasktodo','$Status')";
    $data=mysqli_query($con,$query);
    if ($data) {
        ?>
        
        <?php
           header("location:meeting2.php");
           


    }
    else
    {
        ?>
        
        <?php
    }
    
}

?>

</body>
</html>