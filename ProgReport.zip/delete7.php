<?php
	$id=$_GET['id'];
	include('connection.php');
	mysqli_query($con,"delete from `activity` where id='$id'");
	header('location:activity.php');
?>