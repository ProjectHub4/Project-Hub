<?php
	include('connection.php');
	$id=$_GET['id'];
    $password = $_POST['password'];
	$projecttitle = $_POST['projecttitle'];
    $student1 = $_POST['student1'];
    $student2 = $_POST['student2'];
    $student3 = $_POST['student3'];
    $student4 = $_POST['student4'];
    $batch = $_POST['batch'];
    $year = $_POST['year'];
    $supervisor = $_POST['supervisor'];

	mysqli_query($con,"update `project_form` set projecttitle='$projecttitle', student1='$student1', student2='$student2', student3='$student3', student4='$student4', batch='$batch', year='$year', supervisor='$supervisor' where id='$id'");
	header('location:Admin.php');
?>