<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$fullname=$_POST['fullname'];
	$enrollment=$_POST['enrollment'];
	$batch=$_POST['batch'];
	$year=$_POST['year'];
	
 
	mysqli_query($con,"update `students` set fullname='$fullname', enrollment='$enrollment', batch='$batch', year='$year'  where id='$id'");
	header('location:Admin-students.php');
?>