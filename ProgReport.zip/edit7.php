<?php
	include('connection.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"select * from `progress_form` where id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Form</title>
<link rel="stylesheet" type="text/css" href="style2.css">
<style>
    .button{
        display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 390px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
    }
    .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;

    }

    .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }
    .button:hover span{
            padding-right: 25px;
        }

    .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        
    </style>
</head>
<body>
	
	<form method="POST" action="update5.php?id=<?php echo $id; ?>">
    <h2>Edit Progress Form</h2>
        <label><b>Project Title:</b></label><input type="text" value="<?php echo $row['projecttitle']; ?>" name="projecttitle">
        <label><b>Task:</b></label><input type="text" value="<?php echo $row['task']; ?>" name="task">
		<label><b>Remarks:</b></label><input type="text" value="<?php echo $row['remarks']; ?>" name="remarks">
        <label><b>Status:</b></label><select value ="<?php echo $row['status']; ?>" name="status">
        <option value="Select">Select</option>
                <option value="Satisfactory">Satisfactory</option>
                <option value="Unsatisfactory">Unsatisfactory</option>

            </select>
            <br>
        <br>
        <button class="button" style="vertical-align:middle" name="submit" ><span>Submit</span> </button><br>
	
        <br>
        <br>
       
        <button class="button" onclick="location.href='ProgReport3.php';" value="Back" ><span>Cancel</span> </button><br><br>
	</form>
</body>
</html>