<?php
	include('connection.php');
	$id=$_GET['id'];
 
	$projecttitle=$_POST['projecttitle'];
	$date=$_POST['date'];
	
    $time=$_POST['time'];
	$discussion=$_POST['discussion'];
	$tasktodo=$_POST['tasktodo'];
	$Status=$_POST['Status'];
 
	mysqli_query($con,"update `meetingform` set projecttitle='$projecttitle', date='$date', time='$time',discussion='$discussion',tasktodo='$tasktodo', Status='$Status' where id='$id'");
	
	header('location:meeting2.php');
?>


