<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Project Co-ordinator | Performance Report</title>
    <!-- ======= Styles ====== -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- =============== Navigation ================ -->
    <div class="container" style="background-color:#2a2185;" >
        <div class="navigation"  style="background-color:#2a2185;">
            <ul>
                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name=""></ion-icon>
                        </span>
                        <h1 span class="title"><b>Project Hub</span></h1></b>
                    </a>
                </li>

                <li>
                    <a href="index2.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="activity.php">
                        <span class="icon">
                            <ion-icon name="create-outline"></ion-icon>
                        </span>
                        <span class="title">Activity</span>
                    </a>
                </li>
                <li>
                    <a href="meeting2.php">
                        <span class="icon">
                            <ion-icon name="people-outline"></ion-icon>
                        </span>
                        <span class="title">Meetings</span>
                    </a>
                </li>

                <li>
                    <a href="ProgReport2.php">
                        <span class="icon">
                            <ion-icon name="star-outline"></ion-icon>
                        </span>
                        <span class="title">Progress Report</span>
                    </a>
                </li>

                <li>
                    <a href="project2.php">
                        <span class="icon">
                            <ion-icon name="book-outline"></ion-icon>
                        </span>
                        <span class="title">Projects</span>
                    </a>
                </li>

                <li>
                    <a href="review2.php">
                        <span class="icon">
                            <ion-icon name="chatbubble-outline"></ion-icon>
                        </span>
                        <span class="title">Reviews</span>
                    </a>
                </li>
               

                
                <li>
                    <a href="Templates2.php">
                        <span class="icon">
                            <ion-icon name="card-outline"></ion-icon>
                        </span>
                        <span class="title">Templates</span>
                    </a>
                </li>

 
               

                <li>
                    <a href="login.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">Log out</span>
                    </a>
                </li>
            </ul>
        </div>

        <!-- ========================= Main ==================== -->
        <style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        .main{
            background-image:url(https://img.freepik.com/premium-vector/white-background-with-halftone_67845-798.jpg?w=2000);
        }
        </style>
        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <center><h1><b>PROJECT CO-ORDINATOR | PROGRESS REPORT</b></h1></center>
                

                <div class="user">
               
                
                </div>
            </div>

            <!-- ======================= Cards ================== -->
            <div class="cardBox" >
                

                

                

               
            </div>

            <!-- ================ Order Details List ================= -->
            <?php include 'connection.php'; ?>
            <div class="details"  >
                <div class="recentOrders" style="background-color:#f5f5f5;">
                    <div class="cardHeader">
                        <h2><b>PROGRESS REPORT</b></h2>
                       
                        <a href="progress_form.php">
                <button class="button" style="vertical-align:middle"  ><span>+Add Project Performance</span> </button>
    </a>
    
    
            
                        </div>
                        
                        <table>
                       
    <thead>
        <table border="3px" cellppadding="5px" cellspacing="5px">
        <tr style="background-color: #A9A6CE;">
         <td><b><center>PROJECT TITLE</center></b></td>
    
   
         <td colspan="4" style="text-align:left; border-collapse: collapse;"><b><center>STUDENT's NAMES</center></b></td>
    
        <td colspan="6"><b><center>TASK</center></b></td>
        <td colspan=""><b><center>OBTAINED MARKS</center></b></td>
        <td><b><center>REMARKS</center></b></td>
      
        <td ><b><center>STATUS</center></b></td>
       
        <td colspan=""><center><b></b></center></td>
        </tr>
        
            
        <tr style="background-color: #A9A6CE;">
                            <td><center><b></b></center></td>
                            <td><center><b>1.</b></center></td>
                            <td><center><b>2.</b></center></td>
                            <td><center><b>3.</b></center></td>
                            <td><center><b>4.</b></center></td>
                            <td colspan=""><center><b>Code Evaluation</b></center></td>
                            <td><center><b> Project Evaluation</b></center></td>
                            <td colspan=""><center><b>Participation</b></center></td>
                            <td colspan=""><center><b>Mid Evaluation</b></center></td>
                            <td colspan=""><center><b>Final Evaluation</b></center></td>
                            <td colspan=""><center><b>Performance</b></center></td>
                            <td colspan=""><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td>
                            <td colspan=""><center><b></b></center></td>
                        
                            
                            <td colspan=""><center><b>Actions</b></center></td>
                           
        </tr>
    </thead>

    <tbody>
       
      
    </tbody>
       
   
    
    <?php
        $query="SELECT * FROM progress_form";
        $data=mysqli_query($con,$query);
        $result=mysqli_num_rows($data);
        if ($result) {
            while ($row=mysqli_fetch_array($data)) {
                ?>
                <tr>
                    <td><center><b><?php echo $row['projecttitle']; ?></b></center>
                    </td>
                    <td>
                    <center><b><?php echo $row['student1']; ?></center></b>
            </td>
            <td>
                    <center><b><?php echo $row['student2']; ?></center></b>
            </td>    
                 <td>   <center><b><?php echo $row['student3']; ?></center></b>
            </td>
            <td>
                <center><b><?php echo $row['student4']; ?></center></b>
            </td>
                    <td><center><b><?php echo $row['CodeEvaluation']; ?></center></b>
                    </td>
                    <td><center><b><?php echo $row['ProjectEvaluation']; ?></center></b>
                    </td>
                    <td><center><b><?php echo $row['Performance']; ?></center></b>
                    </td>
                    <td><center><b><?php echo $row['Participation']; ?></center></b>
                    </td>
                    <td><center><b><?php echo $row['MidEvaluation']; ?></center></b>
                    </td>
                    <td><center><b><?php echo $row['FinalEvaluation']; ?></center></b>
                    </td>
                    
                    <td><b><center><?php echo $row['obtmarks'];?></center></b>
                    </td>
                   
                    <td><center><b><?php echo $row['remarks']; ?></center></b>
                    </td>
            
                    <td><center><b><span class="status inProgress"><?php echo $row['status']; ?></b></center></span>
                    </td>
                    
                     <td>
                    <center><b><a href="delete8.php?id=<?php echo $row['id']; ?>"style="color: red"><ion-icon name="close-circle-outline" size="large" ></a></center></b>
							</td>
                </tr>
                <?php
            }
        }
    ?>
</table>

</div>


                <!-- ================= New Customers ================ -->
                

    <!-- =========== Scripts =========  -->
    <script src="assets/js/main.js"></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
</body>
</html>