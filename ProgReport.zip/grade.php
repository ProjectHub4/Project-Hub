
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Style2.css">
<style>
        .button{
            display:inline-block;
            border-radius:9px;
            background-color: #2a2185;
            border:none;
            color: #FFFFFF;
            text-align: center;
            font-size: 20px;
            padding: 7px;
            width: 180px;
            transition: all 0.5s;
            cursor:pointer:
            margin: 5px;
        }

        .button span{
        cursor: pointer;
        display: inline-block;
        position: relative;
        transition: 0.5s;
        }

        .button span:after{
            content:'\00bb';
            position: absolute;
            opacity: 0;
            top:0
            right: -20px;
            transition: 0.5s;
        }

        .button:hover span{
            padding-right: 25px;
        }

        .button:hover span:after{
            opacity: 1;
            right: 0;
        }
        </style>
</head>
<body>
   <h1 style="color: white;">
      Progress Report
   </h1>
   
   <center>
 <thead>
   <table border="1" cellspacing="5" bgcolor="white">
      <caption style="color:white;"><b>Enter Marks</b></caption>
      <tr style="background: silver;">
         <td rowspan="2"><center>Student's Name</center></td>
         <td colspan="8"><center>Marks</center></td>
      </tr>
      <tr style="background: silver;">
         <td><center>Code Evaluation</center></td>
		 <td><center>Mid  Evaluation</center></td>
         
         <td><center>Final  Evaluation</center></td>
         
         <td><center>Performance Evaluation</center></td>
         <td><center>Participation</center></td>
      </tr>
      
      <tr>
         <td><input type="text" id="name"></td>
         <td><input type="text" id="code"></td>
         <td><input type="text" id="mid"></td>
         
         <td><input type="text" id="final"></td>
        
         <td><input type="text" id="performance"></td>
         <td><input type="text" id="participation"></td>
         
      </tr>
      <tr>
      </thead>
      <tbody>
      </tbody>
      
         <td colspan="8" height="30" width="40">
         <input type="submit" value="Calculate" onclick="Sub()"></th>
      </tr>
   </table>
   <br>
   
   <table border="1" cellspacing="5" bgcolor="white"
      height="100" width="500" cellpadding="5" id="TableScore">
      <caption style="color:white;"><b>Student Report</b></caption>
     
      <tr>
         <td width="180"><center></center></td>
         <td><center></center></td>
         <td><center></center></td>
         <td><center></center></td>
      </tr>
      
   </table>
   
</center>
<script type="text/javascript">
   function Sub(){
      var n, k, r, e, v, sum, avg;
      n=(document.getElementById('name').value);
      code=parseFloat(document.getElementById('code').value);
      mid=parseFloat(document.getElementById('mid').value);
     
      final=parseFloat(document.getElementById('final').value);
    
      performance=parseFloat(document.getElementById('performance').value);
      participation=parseFloat(document.getElementById('participation').value);
      // Calculating the Total Marks
      sum=code+mid+final+performance+participation;
      avg=sum/2;
      // Displaying the Student Data
      var newTable = document.getElementById('TableScore');
      var row = newTable.insertRow(-1);
      var cell1 = row.insertCell(0);
      var cell2 = row.insertCell(0);
      var cell3 = row.insertCell(0);
      var cell4 = row.insertCell(0);
      
      cell4.innerHTML= n;
      cell3.innerHTML=sum;
      cell2.innerHTML = avg;
      if(avg>=100){
         cell1.innerHTML="<font color=green>Pass</font>";
      } else {
         cell1.innerHTML="<font color=red>Fail</font>";
      }
   }
   
</script>
<br>
<br<br>

</body>
</html>